from typing import Any
from pydantic import BaseModel, Field

class WorldCreate(BaseModel):
    name: str = "Alpha-01"
    seed: int = 42

class EventCreate(BaseModel):
    type: str
    magnitude: float = Field(default=1.0, ge=0, le=2)
    duration: int = Field(default=1, ge=1, le=30)

class ScenarioCreate(BaseModel):
    population_change: float = Field(default=0, ge=-0.5, le=1)
    energy_change: float = Field(default=0, ge=-0.5, le=1)
    food_change: float = Field(default=0, ge=-0.5, le=1)
    traffic_change: float = Field(default=0, ge=-0.5, le=1)

class DecisionRequest(BaseModel):
    horizon: int = Field(default=10, ge=1, le=100)
    objective: str = "Maximize stability over the simulation horizon."

class StateOut(BaseModel):
    world_id: int
    day: int
    population: float
    energy: float
    food: float
    economy: float
    infrastructure: float
    traffic: float
    stability: float
    resources: float

class DecisionOut(BaseModel):
    chosen_action: str
    score: float
    explanation: str
    candidates: list[dict[str, Any]]
