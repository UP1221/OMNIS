from dataclasses import dataclass, asdict
from typing import Any
import random

ACTIONS = [
    "increase_energy_production",
    "repair_infrastructure",
    "reduce_nonessential_demand",
    "increase_food_supply",
    "allocate_resources_to_critical_zone",
]

@dataclass
class State:
    population: float
    energy: float
    food: float
    economy: float
    infrastructure: float
    traffic: float
    stability: float
    resources: float

def clamp(v: float, low: float = 0, high: float = 100) -> float:
    return max(low, min(high, v))

def calculate_stability(s: State) -> float:
    return clamp(
        0.25 * s.energy
        + 0.20 * s.food
        + 0.20 * s.economy
        + 0.20 * s.infrastructure
        + 0.15 * (100 - s.traffic)
    )

def apply_action(s: State, action: str):
    if action == "increase_energy_production":
        s.energy = clamp(s.energy + 10)
        s.resources = clamp(s.resources - 5)
    elif action == "repair_infrastructure":
        s.infrastructure = clamp(s.infrastructure + 10)
        s.resources = clamp(s.resources - 8)
    elif action == "reduce_nonessential_demand":
        s.traffic = clamp(s.traffic - 8)
        s.energy = clamp(s.energy + 4)
    elif action == "increase_food_supply":
        s.food = clamp(s.food + 10)
        s.resources = clamp(s.resources - 5)
    elif action == "allocate_resources_to_critical_zone":
        s.energy = clamp(s.energy + 5)
        s.food = clamp(s.food + 5)
        s.resources = clamp(s.resources - 7)

def step(s: State, active_events: list[dict[str, Any]] | None = None) -> State:
    active_events = active_events or []

    energy_production = 8
    energy_demand = 6 + s.population / 25000
    food_supply = 6
    food_consumption = 5 + s.population / 30000
    productivity = 2.0
    shortages = 0.0
    population_pressure = s.population / 50000

    for event in active_events:
        effects = event.get("effects", {})
        energy_production *= 1 + effects.get("energy_production", 0)
        energy_demand *= 1 + effects.get("energy_demand", 0)
        food_supply *= 1 + effects.get("food_supply", 0)
        food_consumption *= 1 + effects.get("food_consumption", 0)
        productivity *= 1 + effects.get("economy", 0)
        population_delta = effects.get("population", 0)
        s.population = max(100, s.population * (1 + population_delta))

    s.energy = clamp(s.energy + energy_production - energy_demand)
    s.food = clamp(s.food + food_supply - food_consumption)
    s.traffic = clamp(s.traffic + population_pressure * 4 - s.infrastructure / 60)
    shortages = max(0, 50 - min(s.energy, s.food)) / 10
    s.economy = clamp(s.economy + productivity - shortages)
    s.infrastructure = clamp(s.infrastructure - max(0, s.traffic - 70) * 0.03)
    s.resources = clamp(s.resources + 1 - shortages * 0.5)
    s.stability = calculate_stability(s)

    return s

def simulate(initial: State, days: int, events_by_day=None, action=None):
    s = State(**asdict(initial))
    history = []

    for day in range(1, days + 1):
        if action:
            apply_action(s, action)
        events = (events_by_day or {}).get(day, [])
        step(s, events)
        history.append({"day": day, **asdict(s)})

    return s, history

def default_state(seed: int) -> State:
    random.seed(seed)
    return State(
        population=42831,
        energy=78,
        food=64,
        economy=71,
        infrastructure=82,
        traffic=41,
        stability=82,
        resources=100,
    )

EVENTS = {
    "energy_shortage": {
        "energy_production": -0.20,
        "economy": -0.05,
    },
    "factory_shutdown": {
        "energy_production": -0.15,
        "economy": -0.08,
    },
    "population_growth": {
        "population": 0.20,
        "energy_demand": 0.23,
        "food_consumption": 0.19,
    },
    "infrastructure_repair": {
        "food_supply": 0.02,
        "economy": 0.02,
    },
    "demand_surge": {
        "energy_demand": 0.20,
        "food_consumption": 0.20,
    },
    "supply_delay": {
        "food_supply": -0.25,
        "energy_production": -0.10,
    },
}
