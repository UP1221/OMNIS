from .simulation import ACTIONS, State, simulate

def score(state: State) -> float:
    return round(
        0.35 * state.stability
        + 0.20 * state.energy
        + 0.15 * state.food
        + 0.15 * state.economy
        + 0.15 * state.infrastructure,
        3,
    )

def decide(state: State, horizon: int):
    candidates = []

    baseline_final, _ = simulate(state, horizon)
    baseline_score = score(baseline_final)

    for action in ACTIONS:
        final_state, history = simulate(state, horizon, action=action)
        action_score = score(final_state)
        candidates.append({
            "action": action,
            "score": action_score,
            "delta_vs_baseline": round(action_score - baseline_score, 3),
            "final_stability": round(final_state.stability, 2),
            "final_energy": round(final_state.energy, 2),
            "final_food": round(final_state.food, 2),
        })

    candidates.sort(key=lambda x: x["score"], reverse=True)
    chosen = candidates[0]

    bottlenecks = {
        "energy": state.energy,
        "food": state.food,
        "economy": state.economy,
        "infrastructure": state.infrastructure,
    }
    bottleneck = min(bottlenecks, key=bottlenecks.get)

    explanation = (
        f"OMNIS selected '{chosen['action']}' because it produced the highest "
        f"objective score ({chosen['score']}) over {horizon} simulated days. "
        f"The current lowest resource-health indicator is {bottleneck} "
        f"({bottlenecks[bottleneck]:.1f}), which is a contributing bottleneck."
    )

    return chosen, candidates, explanation
