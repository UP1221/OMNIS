from datetime import datetime
from sqlalchemy import DateTime, Float, Integer, String, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

class World(Base):
    __tablename__ = "worlds"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    seed: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class WorldState(Base):
    __tablename__ = "world_states"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    world_id: Mapped[int] = mapped_column(Integer, index=True)
    day: Mapped[int] = mapped_column(Integer, index=True)
    population: Mapped[float] = mapped_column(Float)
    energy: Mapped[float] = mapped_column(Float)
    food: Mapped[float] = mapped_column(Float)
    economy: Mapped[float] = mapped_column(Float)
    infrastructure: Mapped[float] = mapped_column(Float)
    traffic: Mapped[float] = mapped_column(Float)
    stability: Mapped[float] = mapped_column(Float)
    resources: Mapped[float] = mapped_column(Float)

class Event(Base):
    __tablename__ = "events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    world_id: Mapped[int] = mapped_column(Integer, index=True)
    type: Mapped[str] = mapped_column(String(80))
    magnitude: Mapped[float] = mapped_column(Float, default=1.0)
    start_day: Mapped[int] = mapped_column(Integer)
    duration: Mapped[int] = mapped_column(Integer)
    effects: Mapped[dict] = mapped_column(JSON)

class Decision(Base):
    __tablename__ = "decisions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    world_id: Mapped[int] = mapped_column(Integer, index=True)
    day: Mapped[int] = mapped_column(Integer)
    objective: Mapped[str] = mapped_column(Text)
    candidates: Mapped[list] = mapped_column(JSON)
    chosen_action: Mapped[str] = mapped_column(String(100))
    score: Mapped[float] = mapped_column(Float)
    explanation: Mapped[str] = mapped_column(Text)
