from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from sqlalchemy.orm import Session
import os

from .database import Base, engine, get_db
from .models import World, WorldState, Event, Decision
from .schemas import WorldCreate, EventCreate, ScenarioCreate, DecisionRequest
from .simulation import State, default_state, step, EVENTS, simulate
from .decision import decide

Base.metadata.create_all(bind=engine)

app = FastAPI(title="OMNIS API", version="0.1.0")

origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def to_state(row: WorldState) -> State:
    return State(
        population=row.population,
        energy=row.energy,
        food=row.food,
        economy=row.economy,
        infrastructure=row.infrastructure,
        traffic=row.traffic,
        stability=row.stability,
        resources=row.resources,
    )

def state_dict(world_id: int, row: WorldState):
    return {
        "world_id": world_id,
        "day": row.day,
        "population": row.population,
        "energy": row.energy,
        "food": row.food,
        "economy": row.economy,
        "infrastructure": row.infrastructure,
        "traffic": row.traffic,
        "stability": row.stability,
        "resources": row.resources,
    }

@app.get("/health")
def health():
    return {"status": "online", "system": "OMNIS"}

@app.post("/worlds")
def create_world(payload: WorldCreate, db: Session = Depends(get_db)):
    existing = db.scalar(select(World).where(World.name == payload.name))
    if existing:
        return {"id": existing.id, "name": existing.name, "seed": existing.seed}

    world = World(name=payload.name, seed=payload.seed)
    db.add(world)
    db.flush()

    s = default_state(payload.seed)
    row = WorldState(world_id=world.id, day=0, **s.__dict__)
    db.add(row)
    db.commit()
    return {"id": world.id, "name": world.name, "seed": world.seed}

@app.get("/worlds")
def worlds(db: Session = Depends(get_db)):
    return [
        {"id": w.id, "name": w.name, "seed": w.seed}
        for w in db.scalars(select(World)).all()
    ]

@app.get("/worlds/{world_id}")
def get_world(world_id: int, db: Session = Depends(get_db)):
    world = db.get(World, world_id)
    if not world:
        raise HTTPException(404, "World not found")

    row = db.scalar(
        select(WorldState)
        .where(WorldState.world_id == world_id)
        .order_by(WorldState.day.desc())
    )
    if not row:
        raise HTTPException(404, "World state not found")

    return state_dict(world_id, row)

@app.post("/worlds/{world_id}/advance")
def advance(world_id: int, db: Session = Depends(get_db)):
    world = db.get(World, world_id)
    if not world:
        raise HTTPException(404, "World not found")

    current = db.scalar(
        select(WorldState)
        .where(WorldState.world_id == world_id)
        .order_by(WorldState.day.desc())
    )
    events = db.scalars(
        select(Event).where(
            Event.world_id == world_id,
            Event.start_day <= current.day + 1,
            Event.start_day + Event.duration > current.day,
        )
    ).all()

    active_events = [{"effects": e.effects} for e in events]
    s = to_state(current)
    step(s, active_events)

    next_row = WorldState(world_id=world_id, day=current.day + 1, **s.__dict__)
    db.add(next_row)
    db.commit()
    return state_dict(world_id, next_row)

@app.post("/worlds/{world_id}/events")
def inject_event(world_id: int, payload: EventCreate, db: Session = Depends(get_db)):
    world = db.get(World, world_id)
    if not world:
        raise HTTPException(404, "World not found")

    if payload.type not in EVENTS:
        raise HTTPException(
            400,
            f"Unknown event. Choose one of: {', '.join(EVENTS.keys())}"
        )

    current = db.scalar(
        select(WorldState)
        .where(WorldState.world_id == world_id)
        .order_by(WorldState.day.desc())
    )

    effects = {
        key: value * payload.magnitude
        for key, value in EVENTS[payload.type].items()
    }

    event = Event(
        world_id=world_id,
        type=payload.type,
        magnitude=payload.magnitude,
        start_day=current.day + 1,
        duration=payload.duration,
        effects=effects,
    )
    db.add(event)
    db.commit()

    return {
        "id": event.id,
        "type": event.type,
        "start_day": event.start_day,
        "duration": event.duration,
        "effects": event.effects,
    }

@app.post("/worlds/{world_id}/simulate")
def what_if(world_id: int, payload: ScenarioCreate, db: Session = Depends(get_db)):
    current = db.scalar(
        select(WorldState)
        .where(WorldState.world_id == world_id)
        .order_by(WorldState.day.desc())
    )
    if not current:
        raise HTTPException(404, "World not found")

    base = to_state(current)
    scenario = State(**base.__dict__)
    scenario.population *= 1 + payload.population_change
    scenario.energy = max(0, scenario.energy * (1 + payload.energy_change))
    scenario.food = max(0, scenario.food * (1 + payload.food_change))
    scenario.traffic = max(0, scenario.traffic * (1 + payload.traffic_change))
    scenario.stability = (
        0.25 * scenario.energy
        + 0.20 * scenario.food
        + 0.20 * scenario.economy
        + 0.20 * scenario.infrastructure
        + 0.15 * (100 - scenario.traffic)
    )

    final_state, history = simulate(scenario, 10)
    return {
        "baseline": base.__dict__,
        "scenario_start": scenario.__dict__,
        "final": final_state.__dict__,
        "history": history,
    }

@app.post("/worlds/{world_id}/decide")
def recommendation(world_id: int, payload: DecisionRequest, db: Session = Depends(get_db)):
    current = db.scalar(
        select(WorldState)
        .where(WorldState.world_id == world_id)
        .order_by(WorldState.day.desc())
    )
    if not current:
        raise HTTPException(404, "World not found")

    chosen, candidates, explanation = decide(to_state(current), payload.horizon)

    decision = Decision(
        world_id=world_id,
        day=current.day,
        objective=payload.objective,
        candidates=candidates,
        chosen_action=chosen["action"],
        score=chosen["score"],
        explanation=explanation,
    )
    db.add(decision)
    db.commit()

    return {
        "chosen_action": chosen["action"],
        "score": chosen["score"],
        "explanation": explanation,
        "candidates": candidates,
    }

@app.get("/worlds/{world_id}/history")
def history(world_id: int, db: Session = Depends(get_db)):
    rows = db.scalars(
        select(WorldState)
        .where(WorldState.world_id == world_id)
        .order_by(WorldState.day.asc())
    ).all()
    return [state_dict(world_id, r) for r in rows]

@app.get("/worlds/{world_id}/decisions")
def decisions(world_id: int, db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Decision)
        .where(Decision.world_id == world_id)
        .order_by(Decision.id.desc())
    ).all()
    return [
        {
            "id": d.id,
            "day": d.day,
            "objective": d.objective,
            "chosen_action": d.chosen_action,
            "score": d.score,
            "explanation": d.explanation,
            "candidates": d.candidates,
        }
        for d in rows
    ]
