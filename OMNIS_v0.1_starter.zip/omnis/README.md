# OMNIS

Autonomous Simulation & Decision Intelligence Platform.

This is the first implementation milestone from the OMNIS project manual:
- deterministic simulation
- event engine
- what-if simulation
- transparent decision engine
- FastAPI REST backend
- React + TypeScript + Vite command center
- PostgreSQL persistence

## 1. Requirements

- Python 3.11+
- Node.js 20+
- PostgreSQL 15+ OR Docker

## 2. Run PostgreSQL

```bash
docker compose up -d db
```

## 3. Backend

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
# source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Backend API: http://localhost:8000
Swagger: http://localhost:8000/docs

## 4. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Current demo flow

1. Create/load World Alpha-01.
2. Advance one simulation day.
3. Inject an event such as Population Growth or Energy Shortage.
4. Run a what-if simulation.
5. Ask OMNIS to evaluate safe candidate actions.
6. Inspect the score and explanation.

The simulation deliberately stays deterministic and explainable before adding advanced ML/RL.
