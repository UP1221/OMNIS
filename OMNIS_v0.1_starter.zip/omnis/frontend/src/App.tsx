import { useEffect, useState } from "react";
import {
  advanceWorld,
  createWorld,
  decide,
  getHistory,
  getWorld,
  injectEvent,
  runScenario,
} from "./api";

type State = {
  world_id: number;
  day: number;
  population: number;
  energy: number;
  food: number;
  economy: number;
  infrastructure: number;
  traffic: number;
  stability: number;
  resources: number;
};

const initial: State = {
  world_id: 1,
  day: 0,
  population: 0,
  energy: 0,
  food: 0,
  economy: 0,
  infrastructure: 0,
  traffic: 0,
  stability: 0,
  resources: 0,
};

function Metric({ label, value, suffix = "" }: {label:string; value:number; suffix?:string}) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value.toFixed(1)}{suffix}</strong>
    </div>
  );
}

export default function App() {
  const [worldId, setWorldId] = useState<number | null>(null);
  const [state, setState] = useState<State>(initial);
  const [history, setHistory] = useState<State[]>([]);
  const [decision, setDecision] = useState<any>(null);
  const [event, setEvent] = useState("population_growth");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("INITIALIZING OMNIS...");

  async function refresh(id: number) {
    const [current, hist] = await Promise.all([
      getWorld(id),
      getHistory(id),
    ]);
    setState(current);
    setHistory(hist);
  }

  async function boot() {
    setLoading(true);
    try {
      const world = await createWorld("Alpha-01", 42);
      setWorldId(world.id);
      await refresh(world.id);
      setMessage("WORLD ONLINE // SIMULATION READY");
    } catch (e: any) {
      setMessage(`SYSTEM ERROR // ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    boot();
  }, []);

  async function act(fn: () => Promise<any>, success: string) {
    if (!worldId) return;
    setLoading(true);
    try {
      await fn();
      await refresh(worldId);
      setMessage(success);
    } catch (e: any) {
      setMessage(`ERROR // ${e.message}`);
    } finally {
      setLoading(false);
    }
  }

  const maxHistory = Math.max(...history.map(x => x.stability), 100);

  return (
    <div className="app">
      <aside>
        <div className="brand">
          <div className="brand-mark">Ω</div>
          <div>
            <h1>OMNIS</h1>
            <small>DECISION INTELLIGENCE</small>
          </div>
        </div>

        <div className="system-status">
          <span className="dot" />
          CORE ONLINE
        </div>

        <nav>
          <a className="active">COMMAND CENTER</a>
          <a>SCENARIO BUILDER</a>
          <a>SIMULATION</a>
          <a>DECISION CENTER</a>
          <a>HISTORY</a>
          <a>SETTINGS</a>
        </nav>

        <div className="sidebar-footer">
          WORLD<br />
          <strong>ALPHA-01</strong><br /><br />
          SEED <strong>42</strong><br />
          DAY <strong>{state.day}</strong>
        </div>
      </aside>

      <main>
        <header>
          <div>
            <div className="eyebrow">AUTONOMOUS SIMULATION & DECISION INTELLIGENCE</div>
            <h2>Command Center</h2>
          </div>
          <div className="status-box">
            <span className="dot" />
            {message}
          </div>
        </header>

        <section className="hero">
          <div>
            <div className="eyebrow">CURRENT WORLD STATE</div>
            <h3>Alpha-01</h3>
            <p>Controllable digital model // human administrator mode</p>
          </div>
          <button onClick={() => act(() => advanceWorld(worldId!), "SIMULATION ADVANCED // +1 DAY")} disabled={loading}>
            ADVANCE SIMULATION
          </button>
        </section>

        <section className="metrics">
          <Metric label="POPULATION" value={state.population} />
          <Metric label="ENERGY" value={state.energy} />
          <Metric label="FOOD" value={state.food} />
          <Metric label="ECONOMY" value={state.economy} />
          <Metric label="INFRASTRUCTURE" value={state.infrastructure} />
          <Metric label="TRAFFIC" value={state.traffic} />
          <Metric label="STABILITY" value={state.stability} />
          <Metric label="RESOURCES" value={state.resources} />
        </section>

        <section className="grid">
          <div className="panel world-map">
            <div className="panel-title">SIMULATED WORLD <span>3 ZONES</span></div>
            <div className="map">
              <div className="zone z1"><b>ZONE 01</b><small>CORE</small></div>
              <div className="zone z2"><b>ZONE 02</b><small>INDUSTRIAL</small></div>
              <div className="zone z3"><b>ZONE 03</b><small>RESIDENTIAL</small></div>
              <div className="route r1" /><div className="route r2" />
            </div>
          </div>

          <div className="panel">
            <div className="panel-title">STABILITY TIMELINE <span>LIVE</span></div>
            <div className="chart">
              {history.slice(-24).map((item, i) => (
                <div
                  key={item.day}
                  className="bar"
                  title={`Day ${item.day}: ${item.stability.toFixed(1)}`}
                  style={{ height: `${Math.max(5, (item.stability / maxHistory) * 100)}%` }}
                />
              ))}
            </div>
          </div>
        </section>

        <section className="grid lower">
          <div className="panel">
            <div className="panel-title">EVENT ENGINE</div>
            <p className="muted">Inject a controlled event into the simulation.</p>
            <select value={event} onChange={e => setEvent(e.target.value)}>
              <option value="population_growth">Population Growth +20%</option>
              <option value="energy_shortage">Energy Shortage</option>
              <option value="factory_shutdown">Factory Shutdown</option>
              <option value="demand_surge">Demand Surge</option>
              <option value="supply_delay">Supply Delay</option>
              <option value="infrastructure_repair">Infrastructure Repair</option>
            </select>
            <button className="secondary" onClick={() => act(() => injectEvent(worldId!, event), "EVENT QUEUED // NEXT SIMULATION STEP")}>
              INJECT EVENT
            </button>
          </div>

          <div className="panel">
            <div className="panel-title">WHAT-IF ANALYSIS</div>
            <p className="muted">Simulate a population increase of 20% for 10 days.</p>
            <button className="secondary" onClick={async () => {
              if (!worldId) return;
              const result = await runScenario(worldId, {
                population_change: 0.20,
                energy_change: 0,
                food_change: 0,
                traffic_change: 0
              });
              setDecision({ type: "scenario", result });
              setMessage(`WHAT-IF COMPLETE // STABILITY ${result.final.stability.toFixed(1)}`);
            }}>
              RUN SCENARIO
            </button>
            {decision?.type === "scenario" && (
              <div className="result">
                Stability: <strong>{decision.result.baseline.stability.toFixed(1)}</strong>
                {" → "}
                <strong>{decision.result.final.stability.toFixed(1)}</strong>
              </div>
            )}
          </div>

          <div className="panel decision">
            <div className="panel-title">DECISION ENGINE <span>AI CORE</span></div>
            <p className="muted">Evaluate whitelisted actions against the stability objective.</p>
            <button onClick={async () => {
              if (!worldId) return;
              setLoading(true);
              try {
                const result = await decide(worldId, 10);
                setDecision({ type: "decision", result });
                setMessage(`RECOMMENDATION READY // ${result.chosen_action}`);
              } finally {
                setLoading(false);
              }
            }}>
              GENERATE RECOMMENDATION
            </button>
            {decision?.type === "decision" && (
              <div className="decision-result">
                <div className="recommendation">{decision.result.chosen_action}</div>
                <div className="score">OBJECTIVE SCORE {decision.result.score}</div>
                <p>{decision.result.explanation}</p>
                <div className="candidate-list">
                  {decision.result.candidates.map((c: any) => (
                    <div className="candidate" key={c.action}>
                      <span>{c.action}</span>
                      <strong>{c.score}</strong>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
