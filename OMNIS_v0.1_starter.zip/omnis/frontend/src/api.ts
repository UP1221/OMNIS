const API = "http://localhost:8000";

export async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `HTTP ${res.status}`);
  }

  return res.json();
}

export const createWorld = (name = "Alpha-01", seed = 42) =>
  api<{id:number}>("/worlds", {
    method: "POST",
    body: JSON.stringify({ name, seed }),
  });

export const getWorld = (id: number) => api<any>(`/worlds/${id}`);
export const advanceWorld = (id: number) =>
  api<any>(`/worlds/${id}/advance`, { method: "POST" });

export const injectEvent = (id: number, type: string, duration = 5) =>
  api<any>(`/worlds/${id}/events`, {
    method: "POST",
    body: JSON.stringify({ type, magnitude: 1, duration }),
  });

export const runScenario = (id: number, body: any) =>
  api<any>(`/worlds/${id}/simulate`, {
    method: "POST",
    body: JSON.stringify(body),
  });

export const decide = (id: number, horizon = 10) =>
  api<any>(`/worlds/${id}/decide`, {
    method: "POST",
    body: JSON.stringify({
      horizon,
      objective: "Maximize stability over the simulation horizon.",
    }),
  });

export const getHistory = (id: number) => api<any[]>(`/worlds/${id}/history`);
